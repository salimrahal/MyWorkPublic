package gov.nist.javax.sip.message;

import javax.sip.message.Request;

/**
 * Extensions for the JAIN-SIP Request interface.
 */
public interface RequestExt extends Request, MessageExt {
	
}
