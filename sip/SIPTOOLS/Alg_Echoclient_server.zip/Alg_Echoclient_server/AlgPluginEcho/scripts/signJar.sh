
jarsigner -keystore /home/salim/Development/mykeystore/siptools.jks /home/salim/Development/MyWorkPublic/sip/SIPTOOLS/Alg_Echoclient_server/AlgPluginEcho/dist/AlgPluginEcho.jar nexogi.com