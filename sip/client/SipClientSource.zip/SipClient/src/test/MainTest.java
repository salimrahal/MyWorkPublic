/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import bo.ConfBO;
import bo.SipClientBO;
import controller.ClientController;
import java.io.PrintWriter;
import java.text.ParseException;
import javax.sip.InvalidArgumentException;
import javax.sip.SipException;
import javax.sip.message.Request;
import vo.ConfVO;
import vo.PrintWriterObj;

/**
 *
 * @author salim
 * Successful Subscribe scenario:
1- Action: Send register request for 299 SIP ID via 299@localIp , 
     Result: 200 Ok / got expires 27 sec
2-Action: send subscribe to 299@ServerIP/event:presence:
   Result: 200 Ok / expires: 3601
3- Action Subscribe to sip:122@173.231.103.38:5060 / event:presence
    Result: 200 OK / expires: 3601
4- SIP Id 112
5- SIP Id 140
6- SIP Id : 125 

 */
public class MainTest {
      public static void main(String args[]) throws ParseException, InvalidArgumentException, SipException, Exception {
       // ConfVO confObj = ConfBO.retrieveConfigurations("./conf/properties.xml");
         //Build the singleton Config File
        ConfVO conVO = ConfVO.getInstance();
        conVO.setUASIp("173.231.103.38");
        conVO.setUASPort(5060);
        
        //local conf
        //my public IP
        conVO.setUACIp("46.249.204.123");
        // conVO.setUACIp("141.138.190.151");
        conVO.setUACPort(5060);
        conVO.setHostNameLocal("salim-server");
        conVO.setExtSipLocal("299");
        conVO.setDomain("TALKSWITCH");
        conVO.setUsername("user299");
        conVO.setPassword("Winter2013");
        conVO.setProtocol("udp");
        conVO.setInstanceUUID("53239363-3df9-4f86-8b57-5dd509207441");
        System.out.println(conVO.toString());
       
          //Request req = testsip.registerStateful(requestURITextField, null);
        /*Subs response:
         * ext 122: error 500
         *     112: 200 Ok , 500 internal error 
         *     140: error 500
         * 125: internal error
        **/
          /*
           *  each subscription should be a Thread
           */
        //NameRunnable n = new NameRunnable();
        //n.run();
        
          
    }
}
