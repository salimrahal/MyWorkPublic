/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bo;

import dao.SymbolMap;
import java.io.File;
import vo.ConfVO;

/**
 *
 * @author salim
 * <properties>
 * <comment>add comments</comment>
 * <entry key="SIP-SERVER">173.231.103.38</entry>
 * <entry key="SIP-SERVER-PORT">5060</entry>
 * <entry key="Local-IP"></entry>
 * <entry key="SIP-LOCAL-PORT">5060</entry>
 * <entry key="SIP-ID">299</entry>
 * <entry key="SIP-Realm/Domain">TALKSWITCH</entry>
 * <entry key="SIP-Auth-ID">user299</entry>
 * <entry key="SIP-PASSWORD">Winter2013</entry>
 * <entry
 * key="SIP-LOCAL-MACHINE-ID">b671df70-60b5-11e3-949a-0800200c9a66</entry>
 * </properties>
 */
public class ConfBO {

    public static ConfVO retrieveConfigurations(String fileURI) {
        ConfVO confObj =  ConfVO.getInstance();
        SymbolMap symbolmap = new SymbolMap(new File(fileURI));
        confObj.setUASIp(symbolmap.lookupSymbol("SIP-SERVER"));
       // System.out.println("-->"+symbolmap.lookupSymbol("SIP-SERVER-PORT"));
        confObj.setUASPort(Integer.valueOf(symbolmap.lookupSymbol("SIP-SERVER-PORT")));
        confObj.setProtocol(symbolmap.lookupSymbol("TRANSPORT-PROTOCOL"));
        confObj.setUACIp(symbolmap.lookupSymbol("Local-IP"));
        confObj.setUACPort(Integer.valueOf(symbolmap.lookupSymbol("SIP-LOCAL-PORT")));
        confObj.setExtSipLocal(symbolmap.lookupSymbol("SIP-ID"));
        confObj.setDomain(symbolmap.lookupSymbol("SIP-Realm/Domain"));
        confObj.setUsername(symbolmap.lookupSymbol("SIP-Auth-ID"));
        confObj.setPassword(symbolmap.lookupSymbol("SIP-PASSWORD"));
        //TODO build the Array of extensions to monitor
        confObj.setExtsToMonitor(null);//param name: SIP-IDs-TO-MONITOR
        confObj.setInstanceUUID(symbolmap.lookupSymbol("SIP-LOCAL-MACHINE-UUID"));    
        return confObj;

    }
    
}
